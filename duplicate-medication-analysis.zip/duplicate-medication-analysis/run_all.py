"""一鍵重跑：解析 → 統計分析 → 產出 Excel → 區間比較。"""
import runpy
from pathlib import Path
src = Path(__file__).resolve().parent / 'src'
for s in ['parse_data.py', 'analyze.py', 'build_report.py', 'period_compare.py']:
    print(f'\n=== {s} ==='); runpy.run_path(str(src / s), run_name='__main__')
