"""115/01–05 低谷區間與各對照區間比較（過度離散校正之率比檢定 + Mann-Whitney，Holm 校正）。"""
import pickle, numpy as np, pandas as pd
from pathlib import Path
from scipy import stats
from statsmodels.stats.multitest import multipletests

ROOT = Path(__file__).resolve().parents[1]; BUILD = ROOT / 'build'
phi = pickle.load(open(BUILD / 'out.pkl', 'rb'))['phi']
df = pd.read_pickle(BUILD / 'wide.pkl')
allm = [c for c in df.columns if isinstance(c, int)]
X = df.set_index(['no', 'name'])[allm].astype(int); t = X.sum()
rng = lambda a, b: [m for m in allm if a <= m <= b]

A = rng(11501, 11505)
comps = [('113/01-05', rng(11301, 11305)), ('114/01-05', rng(11401, 11405)),
         ('114/08-12（緊鄰前5月）', rng(11408, 11412)), ('114/04-12（前一變點區段）', rng(11404, 11412)),
         ('115/06-10', rng(11506, 11510)), ('115/06-09（排除未結束之10月）', rng(11506, 11509))]
rows = []
for name, B in comps:
    SA, SB = t[A].sum(), t[B].sum()
    rr = (SA / len(A)) / (SB / len(B)); se = np.sqrt(phi * (1 / SA + 1 / SB))
    rows.append(dict(對照區間=name, 對照月平均=SB / len(B), **{'115/01-05月平均': SA / len(A)}, 率比=rr,
                     CI下=np.exp(np.log(rr) - 1.96 * se), CI上=np.exp(np.log(rr) + 1.96 * se),
                     p=2 * stats.norm.sf(abs(np.log(rr) / se)), MannWhitney_p=stats.mannwhitneyu(t[A], t[B]).pvalue,
                     **{'115/01-05醫師數': int((X[A].sum(axis=1) > 0).sum()), '對照醫師數': int((X[B].sum(axis=1) > 0).sum())}))
res = pd.DataFrame(rows); res['Holm_p'] = multipletests(res.p, method='holm')[1]
res.to_csv(ROOT / 'output' / '115-01至05_區間比較.csv', index=False, encoding='utf-8-sig')
print(res.round(4).to_string())
print('\n連續5個月合計最低：\n', t[rng(11301, 11510)].rolling(5).sum().nsmallest(3))
