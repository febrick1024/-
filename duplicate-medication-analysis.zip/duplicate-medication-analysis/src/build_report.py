import pandas as pd, numpy as np, pickle
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter as L
from openpyxl.formatting.rule import CellIsRule, ColorScaleRule

from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; BUILD = ROOT/'build'
out = pickle.load(open(BUILD/'out.pkl','rb'))
df = pd.read_pickle(BUILD/'wide.pkl')
allm = [c for c in df.columns if isinstance(c,int)]
M = [m for m in allm if 11301<=m<=11510]
lab = lambda m: f"{m//100}/{m%100:02d}"
q_of = lambda m: f"{m//100}Q{(m%100-1)//3+1}"

F='Arial'
H=Font(name=F,bold=True,color='FFFFFF'); HF=PatternFill('solid',fgColor='305496')
B=Font(name=F); BB=Font(name=F,bold=True); T=Font(name=F,bold=True,size=13)
NOTE=Font(name=F,italic=True,color='595959',size=9)
SIG=PatternFill('solid',fgColor='F8CBAD'); TOT=PatternFill('solid',fgColor='DDEBF7')
thin=Side(style='thin',color='BFBFBF')
wb=Workbook()

def hdr(ws,r,cols,c0=1):
    for i,c in enumerate(cols):
        x=ws.cell(r,c0+i,c); x.font=H; x.fill=HF; x.alignment=Alignment(horizontal='center',vertical='center',wrap_text=True)
def finish(ws,widths=None,freeze=None):
    for row in ws.iter_rows():
        for c in row:
            if c.font is None or c.font.name!=F: c.font=Font(name=F,bold=c.font.bold if c.font else False)
    if widths:
        for k,v in widths.items(): ws.column_dimensions[k].width=v
    if freeze: ws.freeze_panes=freeze
def put(ws,r,c,v,fmt=None,font=None,fill=None):
    if isinstance(v,(np.floating,float)) and np.isnan(v): v=None
    if isinstance(v,np.generic): v=v.item()
    x=ws.cell(r,c,v); x.font=font or B
    if fmt: x.number_format=fmt
    if fill: x.fill=fill
    return x

# ---------------- 醫師_月 ----------------
wd=wb.active; wd.title='醫師_月'
wd['A1']='各醫師每月重複用藥次數（113/01–115/10，共34個月）'; wd['A1'].font=T
wd['A2']='無紀錄月份以 0 計。115/10 資料截至檔案產出日（10/27），當月未結束。'; wd['A2'].font=NOTE
cols=['醫師代號','醫師姓名']+[lab(m) for m in allm]+['總計(34月)','月平均','月SD','開立月數']
hdr(wd,4,cols)
colof={m:3+i for i,m in enumerate(allm)}
c_first=L(colof[11301]); c_last=L(colof[11510])
ctot=3+len(allm)
order=out['doc_info'].index
dm=df.set_index(['no','name'])[allm].astype(int).loc[order]
r0=5
for i,((no,name),row) in enumerate(dm.iterrows()):
    r=r0+i; put(wd,r,1,no); put(wd,r,2,name)
    for m in allm:
        v=int(row[m]); put(wd,r,colof[m],v if v else 0,'0;-0;"-"')
    rng=f"{c_first}{r}:{c_last}{r}"
    put(wd,r,ctot,f"=SUM({rng})",'0',BB); put(wd,r,ctot+1,f"=AVERAGE({rng})",'0.00')
    put(wd,r,ctot+2,f"=STDEV({rng})",'0.00'); put(wd,r,ctot+3,f'=COUNTIF({rng},">0")','0')
rT=r0+len(dm)
put(wd,rT,1,'總計',font=BB,fill=TOT); put(wd,rT,2,'全部醫師',font=BB,fill=TOT)
for m in allm:
    c=L(colof[m]); put(wd,rT,colof[m],f"=SUM({c}{r0}:{c}{rT-1})",'0',BB,TOT)
put(wd,rT,ctot,f"=SUM({c_first}{rT}:{c_last}{rT})",'0',BB,TOT)
put(wd,rT,ctot+1,f"=AVERAGE({c_first}{rT}:{c_last}{rT})",'0.0',BB,TOT)
put(wd,rT,ctot+2,f"=STDEV({c_first}{rT}:{c_last}{rT})",'0.0',BB,TOT)
w={'A':10,'B':10};
for m in allm: w[L(colof[m])]=7.5
for k in range(4): w[L(ctot+k)]=10
finish(wd,w,'C5')
wd.conditional_formatting.add(f"{c_first}{r0}:{c_last}{rT-1}",ColorScaleRule(start_type='num',start_value=0,start_color='FFFFFF',end_type='max',end_color='F4B183'))
TOTROW=rT

# ---------------- 全院_月 ----------------
wm=wb.create_sheet('全院_月',0)
wm['A1']='全部醫師合計：每月統計（113/01–115/10）'; wm['A1'].font=T
cols=['月份','季','總計','開立醫師數','每位醫師平均','醫師間SD','中位數','單一醫師最高','上月','MoM','去年同月','YoY',
      '所屬區段(變點)','區段月平均','區段內標準化殘差','區段內異常(|z|>2)','MoM p(離散校正)','MoM Holm p','YoY p(離散校正)','YoY Holm p']
hdr(wm,3,cols)
mon=out['monthly']
for i,m in enumerate(M):
    r=4+i; c=L(colof[m]); rng=f"'醫師_月'!{c}{r0}:{c}{TOTROW-1}"
    put(wm,r,1,lab(m)); put(wm,r,2,q_of(m))
    put(wm,r,3,f"='醫師_月'!{c}{TOTROW}",'#,##0',BB)
    put(wm,r,4,f'=COUNTIF({rng},">0")','0')
    put(wm,r,5,f'=AVERAGEIF({rng},">0")','0.00')
    put(wm,r,6,mon.loc[i,'醫師間SD'],'0.00')
    put(wm,r,7,mon.loc[i,'中位數'],'0.0')
    put(wm,r,8,f"=MAX({rng})",'0')
    if allm.index(m)>0:
        pc=L(colof[allm[allm.index(m)-1]]); put(wm,r,9,f"='醫師_月'!{pc}{TOTROW}",'#,##0')
        put(wm,r,10,f"=IFERROR(C{r}/I{r}-1,\"\")",'0.0%')
    else: put(wm,r,9,'無基期')
    if m-100 in colof:
        yc=L(colof[m-100]); put(wm,r,11,f"='醫師_月'!{yc}{TOTROW}",'#,##0'); put(wm,r,12,f"=IFERROR(C{r}/K{r}-1,\"\")",'0.0%')
    else:
        put(wm,r,11,'無基期'); put(wm,r,12,None)
    put(wm,r,13,mon.loc[i,'所屬區段']); put(wm,r,14,mon.loc[i,'區段平均'],'0.0')
    put(wm,r,15,mon.loc[i,'區段內標準化殘差'],'0.00'); put(wm,r,16,mon.loc[i,'區段內異常'])
    for j,k in enumerate(['MoM_p(過度離散校正)','MoM_Holm_p','YoY_p(過度離散校正)','YoY_Holm_p']):
        x=put(wm,r,17+j,mon.loc[i,k],'0.0000')
        if k.endswith('Holm_p') and pd.notna(mon.loc[i,k]) and mon.loc[i,k]<0.05: x.fill=SIG
rE=4+len(M)
put(wm,rE,1,'34個月',font=BB,fill=TOT)
put(wm,rE,3,f"=SUM(C4:C{rE-1})",'#,##0',BB,TOT)
put(wm,rE+1,1,'月平均',font=BB); put(wm,rE+1,3,f"=AVERAGE(C4:C{rE-1})",'0.0',BB)
put(wm,rE+2,1,'月SD',font=BB); put(wm,rE+2,3,f"=STDEV(C4:C{rE-1})",'0.0',BB)
n=rE+4
for t in ['說明：',
 '‧ 每位醫師平均/醫師間SD：僅計當月有開立重複用藥的醫師。中位數、醫師間SD、區段與 p 值為 Python 計算之數值（非公式）。',
 '‧ 變點：對 log(次數+1) 做最適分段，以 BIC 選出 4 段。區段內標準化殘差 = (觀察−區段平均)/√(φ×區段平均)，|z|>2 標示為異常。',
 f"‧ MoM/YoY p：月次數呈明顯過度離散（quasi-Poisson φ≈{out['phi']:.1f}），以 φ 校正後的 log 率比 z 檢定，並以 Holm 法做多重比較校正；粉紅色＝校正後 p<0.05。",
 '‧ 113 年各月無 112 年資料，故無 YoY；113/01 無前月資料，故無 MoM。',
 '‧ 115/10 當月未結束（資料截至 10/27），其 MoM 下降不宜直接解讀。']:
    wm.cell(n,1,t).font=NOTE; n+=1
finish(wm,{'A':9,'B':7,'C':8,'D':9,'E':9,'F':9,'G':7,'H':9,'I':7,'J':8,'K':9,'L':9,'M':15,'N':9,'O':10,'P':10,'Q':10,'R':10,'S':10,'T':10},'C4')
wm.row_dimensions[3].height=45

# ---------------- 全院_季 ----------------
wq=wb.create_sheet('全院_季',1)
wq['A1']='全部醫師合計：每季統計'; wq['A1'].font=T
hdr(wq,3,['季','月數','總計','月平均','月間SD','前季','QoQ','去年同季','YoY','開立醫師數','每位醫師平均(季)','醫師間SD(季)','備註'])
qtr=out['quarterly']
qtot_all={}
for q in sorted({q_of(m) for m in allm}):
    qtot_all[q]=[m for m in allm if q_of(m)==q]
for i,rw in qtr.iterrows():
    r=4+i; q=rw['季']; ms=qtot_all[q]
    refs=','.join(f"'醫師_月'!{L(colof[m])}{TOTROW}" for m in ms)
    put(wq,r,1,q); put(wq,r,2,len(ms))
    put(wq,r,3,f"=SUM({refs})",'#,##0',BB); put(wq,r,4,f"=AVERAGE({refs})",'0.0')
    put(wq,r,5,f"=STDEV({refs})" if len(ms)>1 else None,'0.0')
    qs=sorted(qtot_all)
    if qs.index(q)>0:
        pq=qs[qs.index(q)-1]
        put(wq,r,6,"=SUM("+','.join(f"'醫師_月'!{L(colof[m])}{TOTROW}" for m in qtot_all[pq])+")",'#,##0')
        put(wq,r,7,f'=IFERROR(C{r}/F{r}-1,"")','0.0%')
    else: put(wq,r,6,'無基期')
    yq=f"{int(q[:3])-1}{q[3:]}"
    if yq in qtot_all:
        put(wq,r,8,"=SUM("+','.join(f"'醫師_月'!{L(colof[m])}{TOTROW}" for m in qtot_all[yq])+")",'#,##0'); put(wq,r,9,f'=IFERROR(C{r}/H{r}-1,"")','0.0%')
    else: put(wq,r,8,'無基期')
    put(wq,r,10,rw['開立醫師數'],'0'); put(wq,r,11,rw['每位醫師平均'],'0.00'); put(wq,r,12,rw['醫師間SD'],'0.00')
    put(wq,r,13,rw.get('備註') if isinstance(rw.get('備註'),str) else None)
n=4+len(qtr)+1
wq.cell(n,1,'‧ 113Q1 無前季、113 年各季無去年同季資料。115Q4 僅含未結束的 115/10，QoQ/YoY 不具可比性。').font=NOTE
finish(wq,{'A':8,'B':6,'C':9,'D':9,'E':9,'F':9,'G':9,'H':9,'I':9,'J':10,'K':12,'L':12,'M':26},'B4')
wq.row_dimensions[3].height=32

# ---------------- 全院_年 ----------------
wy=wb.create_sheet('全院_年',2)
wy['A1']='全部醫師合計：年度統計'; wy['A1'].font=T
hdr(wy,3,['年度','涵蓋月份','月數','總計','月平均','月間SD','去年同期','YoY(同期)','開立醫師數','每位醫師平均(年)','醫師間SD(年)'])
yr=out['yearly']
spans={113:[m for m in allm if 11301<=m<=11312],114:[m for m in allm if 11401<=m<=11412],115:[m for m in allm if 11501<=m<=11510]}
for i,rw in yr.iterrows():
    r=4+i; y=int(rw['年度']); ms=spans[y]; a,b=L(colof[ms[0]]),L(colof[ms[-1]])
    rng=f"'醫師_月'!{a}{TOTROW}:{b}{TOTROW}"
    put(wy,r,1,str(y)); put(wy,r,2,rw['涵蓋']); put(wy,r,3,len(ms))
    put(wy,r,4,f"=SUM({rng})",'#,##0',BB); put(wy,r,5,f"=AVERAGE({rng})",'0.0'); put(wy,r,6,f"=STDEV({rng})",'0.0')
    base=[m-100 for m in ms]
    if all(x in colof for x in base):
        put(wy,r,7,f"=SUM('醫師_月'!{L(colof[base[0]])}{TOTROW}:{L(colof[base[-1]])}{TOTROW})",'#,##0'); put(wy,r,8,f'=IFERROR(D{r}/G{r}-1,"")','0.0%')
    else: put(wy,r,7,'無基期')
    put(wy,r,9,rw['開立醫師數'],'0'); put(wy,r,10,rw['每位醫師平均'],'0.00'); put(wy,r,11,rw['醫師間SD'],'0.00')
wy.cell(8,1,'‧ 113 年無 112 年基期；115 年以 114/01–10 同期比較（115/10 未結束）。').font=NOTE
finish(wy,{'A':7,'B':20,'C':6,'D':9,'E':9,'F':9,'G':9,'H':10,'I':10,'J':13,'K':12})

# ---------------- 顯著性檢定 ----------------
wt=wb.create_sheet('顯著性檢定',3)
wt['A1']='全院層級：統計上有意義的差異'; wt['A1'].font=T
r=3; wt.cell(r,1,'A. 變點分析（結構性轉折）').font=BB; r+=1
seg=out['segments']
hdr(wt,r,['區段','月數','月平均','SD','最小','最大','vs 前段 Welch p (log)','vs 前段 Mann-Whitney p']); r+=1
for _,s in seg.iterrows():
    for j,k in enumerate(['區段','月數','月平均','SD','最小','最大','與前段比較_Welch_p(log)','與前段比較_MannWhitney_p']):
        x=put(wt,r,1+j,s[k],'0.0000' if 'p' in k else ('0.0' if j>1 else None))
        if 'p' in k and pd.notna(s[k]) and s[k]<0.05: x.fill=SIG
    r+=1
wt.cell(r,1,'BIC：'+'／'.join(f"{k}段 {v:.1f}" for k,v in out['bic'].items())+'（數值最小者最佳）').font=NOTE; r+=2
wt.cell(r,1,f"B. 季間差異（quasi-Poisson GLM，φ={out['phi']:.2f}；113Q1–115Q3 完整季；Kruskal-Wallis H={out['kw'].statistic:.2f}, p={out['kw'].pvalue:.4f}）").font=BB; r+=1
hdr(wt,r,['QoQ 比較','率比 RR','95% CI 下','95% CI 上','p','Holm 校正 p','顯著']); r+=1
for _,s in out['qtest'].iterrows():
    vals=[s['比較'],s['率比RR'],s['RR_95CI下'],s['RR_95CI上'],s['p'],s['Holm校正p'],'是' if s['顯著(α=0.05)'] else '']
    for j,v in enumerate(vals):
        x=put(wt,r,1+j,v,'0.0000' if j in (4,5) else ('0.00' if j in (1,2,3) else None))
        if s['顯著(α=0.05)']: x.fill=SIG
    r+=1
r+=1; wt.cell(r,1,'C. 季 YoY（去年同季比較，φ 校正）').font=BB; r+=1
hdr(wt,r,['YoY 比較','本期','去年同期','率比 RR','p','Holm 校正 p','顯著']); r+=1
for _,s in out['ytest'].iterrows():
    vals=[s['比較'],s['本期'],s['去年同期'],s['率比RR'],s['p'],s['Holm校正p'],'是' if s['顯著(α=0.05)'] else '']
    for j,v in enumerate(vals):
        x=put(wt,r,1+j,v,'0.0000' if j in (4,5) else ('0.00' if j==3 else None))
        if s['顯著(α=0.05)']: x.fill=SIG
    r+=1
r+=1
for t in ['方法註記：',
 '‧ 本資料只有「次數」，沒有門診人次或處方數等分母；所有比較都是絕對次數，無法排除看診量變化的影響。',
 '‧ 月次數變異遠大於 Poisson 假設，若直接用 Poisson 檢定幾乎每個變化都會「顯著」，因此一律採過度離散校正，結論較保守。',
 '‧ 每季僅 3 個月觀測值，季間檢定的檢定力有限；未達顯著不代表沒有差異。']:
    wt.cell(r,1,t).font=NOTE; r+=1
finish(wt,{'A':18,'B':10,'C':10,'D':10,'E':10,'F':10,'G':16,'H':16})

# ---------------- 醫師_季 ----------------
wdq=wb.create_sheet('醫師_季')
wdq['A1']='各醫師每季次數與 QoQ'; wdq['A1'].font=T
QL=list(out['doc_q'].columns)
hdr(wdq,3,['醫師代號','醫師姓名']+QL+['季平均(113Q1–115Q3)','季SD']+[f'QoQ {q}' for q in QL])
dq=out['doc_q']
for i,(idx,row) in enumerate(dq.iterrows()):
    r=4+i; put(wdq,r,1,idx[0]); put(wdq,r,2,idx[1])
    for j,q in enumerate(QL):
        ms=qtot_all[q]; ref='+'.join(f"'醫師_月'!{L(colof[m])}{r0+i}" for m in ms)
        put(wdq,r,3+j,f"={ref}",'0;-0;"-"')
    a,b=L(3),L(3+len(QL)-2)  # exclude 115Q4 partial
    put(wdq,r,3+len(QL),f"=AVERAGE({a}{r}:{b}{r})",'0.00'); put(wdq,r,4+len(QL),f"=STDEV({a}{r}:{b}{r})",'0.00')
    for j,q in enumerate(QL):
        cur=L(3+j)
        if j==0:
            continue
        else: f_=f'=IFERROR({cur}{r}/{L(2+j)}{r}-1,"")'
        put(wdq,r,5+len(QL)+j,f_,'0%')
rq=4+len(dq)
put(wdq,rq,1,'總計',font=BB,fill=TOT); put(wdq,rq,2,'全部醫師',font=BB,fill=TOT)
for j in range(len(QL)): c=L(3+j); put(wdq,rq,3+j,f"=SUM({c}4:{c}{rq-1})",'#,##0',BB,TOT)
wdq.cell(rq+2,1,'‧ 113Q1 無前季；QoQ 前季為 0 時留空。季平均/SD 不含未結束的 115Q4。').font=NOTE
finish(wdq,{'A':10,'B':10},'C4')

# ---------------- 醫師_年與YoY ----------------
wdy=wb.create_sheet('醫師_年與YoY')
wdy['A1']='各醫師年度次數、YoY 與顯著性'; wdy['A1'].font=T
info=out['doc_info']
cols=['醫師代號','醫師姓名','總計(34月)','開立月數','月平均(34月)','月SD(34月)','有開立月平均','有開立月SD','最高月','最高月次數',
      '113全年','114全年','114(1–10月)','115(1–10月)','YoY 115 vs 114同期','YoY 114 vs 113',
      '同期比較 p(精確)','同期比較 FDR q','月間異質性 p','月間異質性 FDR q']
hdr(wdy,3,cols)
for i,(idx,s) in enumerate(info.iterrows()):
    r=4+i; rr=r0+i
    def rs(m1,m2): return f"=SUM('醫師_月'!{L(colof[m1])}{rr}:{L(colof[m2])}{rr})"
    put(wdy,r,1,idx[0]); put(wdy,r,2,idx[1])
    put(wdy,r,3,f"='醫師_月'!{L(ctot)}{rr}",'0',BB); put(wdy,r,4,f"='醫師_月'!{L(ctot+3)}{rr}",'0')
    put(wdy,r,5,f"='醫師_月'!{L(ctot+1)}{rr}",'0.00'); put(wdy,r,6,f"='醫師_月'!{L(ctot+2)}{rr}",'0.00')
    put(wdy,r,7,s['有開立月平均'],'0.00'); put(wdy,r,8,s['有開立月SD'],'0.00')
    put(wdy,r,9,s['最高月']); put(wdy,r,10,s['最高月次數'],'0')
    put(wdy,r,11,rs(11301,11312),'0'); put(wdy,r,12,rs(11401,11412),'0'); put(wdy,r,13,rs(11401,11410),'0'); put(wdy,r,14,rs(11501,11510),'0')
    put(wdy,r,15,f'=IF(M{r}=0,"",N{r}/M{r}-1)','0%')
    put(wdy,r,16,f'=IF(K{r}=0,"",L{r}/K{r}-1)','0%')
    for j,k in enumerate(['同期比較p(精確檢定)','同期比較FDR q','月間異質性p','月間異質性FDR q']):
        x=put(wdy,r,17+j,s[k],'0.0000')
        if 'q' in k and pd.notna(s[k]) and s[k]<0.05: x.fill=SIG
n=4+len(info)+1
for t in ['‧ 同期比較：115/01–10 vs 114/01–10，條件二項精確檢定（Poisson 率比），以 Benjamini-Hochberg 控制 FDR；粉紅＝q<0.05。',
          '‧ 月間異質性：34 個月次數是否偏離「每月相同」的 Poisson 期待（χ² 離散檢定），僅對總計≥10 的醫師計算；q<0.05 表示該醫師各月份明顯不均。',
          '‧ 「有開立月平均/SD」只計該醫師有紀錄的月份，可避免新進或離職醫師被 0 值拉低。']:
    wdy.cell(n,1,t).font=NOTE; n+=1
finish(wdy,{'A':10,'B':10,'O':12,'P':12,'Q':11,'R':11,'S':11,'T':11},'C4')
wdy.row_dimensions[3].height=45

# ---------------- 醫師_異常月份 ----------------
wa=wb.create_sheet('醫師_異常月份')
wa['A1']='各醫師統計上特別突出的月份（FDR q<0.01）'; wa['A1'].font=T
hdr(wa,3,['醫師代號','醫師姓名','月份','次數','該醫師34月平均','為平均的倍數','Poisson 上尾 p','FDR q'])
an=out['doc_anom'].reset_index(drop=True)
for i,s in an.iterrows():
    r=4+i
    for j,(k,f) in enumerate([('no',None),('name',None),('月份',None),('次數','0'),('該醫師月平均','0.00'),('倍數','0.0"x"'),('p','0.00E+00'),('FDR q','0.00E+00')]):
        put(wa,r,1+j,s[k],f)
wa.cell(5+len(an),1,'‧ 以該醫師 34 個月平均為期待值，檢定單月次數是否顯著偏高；涵蓋總計≥10 的醫師，全部醫師-月份一起做 BH-FDR 校正。').font=NOTE
finish(wa,{'A':10,'B':10,'C':9,'D':7,'E':13,'F':12,'G':13,'H':12},'A4')

# ---------------- 貢獻分析 ----------------
wc=wb.create_sheet('變化來源')
wc['A1']='哪些醫師造成兩次大轉折'; wc['A1'].font=T
r=3
for key,title in [('contrib_drop','下降：114Q3 vs 113Q3（390 → 170）'),('contrib_surge','上升：115Q3 vs 114Q3（170 → 994）')]:
    c,_=out[key]; wc.cell(r,1,title).font=BB; r+=1
    hdr(wc,r,['醫師代號','醫師姓名','前期','後期','變化','佔總變化%']); r+=1
    for (no,name),s in c.head(20).iterrows():
        put(wc,r,1,no); put(wc,r,2,name); put(wc,r,3,int(s.前期),'0'); put(wc,r,4,int(s.後期),'0')
        put(wc,r,5,f"=D{r}-C{r}",'0;-0'); put(wc,r,6,s['佔總變化%'],'0.0%'); r+=1
    r+=1
newd=out['newdoc']
wc.cell(r,1,'115/06 以後才首次出現的醫師').font=BB; r+=1
hdr(wc,r,['醫師代號','醫師姓名','首次出現','總計']); r+=1
for (no,name),s in newd.iterrows():
    put(wc,r,1,no); put(wc,r,2,name); put(wc,r,3,s['首次出現']); put(wc,r,4,int(s['總計']),'0'); r+=1
finish(wc,{'A':10,'B':10,'C':9,'D':9,'E':9,'F':11})

wb.save(ROOT/'output'/'重複用藥統計分析_113-01至115-10.xlsx')
print('ok')
