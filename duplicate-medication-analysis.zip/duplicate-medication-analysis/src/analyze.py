import pandas as pd, numpy as np, itertools, pickle
from scipy import stats
import statsmodels.api as sm
from statsmodels.stats.multitest import multipletests

from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; BUILD = ROOT/'build'
df = pd.read_pickle(BUILD/'wide.pkl')
allm = [c for c in df.columns if isinstance(c, int)]
M = [m for m in allm if 11301 <= m <= 11510]          # 34 months in scope
lab = lambda m: f"{m//100}/{m%100:02d}"
def q_of(m): return f"{m//100}Q{(m%100-1)//3+1}"
def y_of(m): return m//100

X = df.set_index(['no','name'])[allm].astype(int)       # includes 113/01-09 as YoY baseline
XS = X[M]
tot_all = X.sum()

out = {}
# ---------------- Overall: monthly ----------------
rows=[]
for m in M:
    col = X[m]; act = col[col>0]
    prev = allm[allm.index(m)-1] if allm.index(m)>0 else None
    yo = m-100
    r = dict(月份=lab(m), 季=q_of(m), 總計=int(col.sum()), 開立醫師數=len(act),
             每位醫師平均=act.mean(), 醫師間SD=act.std(ddof=1) if len(act)>1 else np.nan,
             中位數=act.median(), 最大單一醫師=int(act.max()),
             MoM=(col.sum()/tot_all[prev]-1) if prev else np.nan,
             YoY=(col.sum()/tot_all[yo]-1) if yo in tot_all and tot_all[yo] else np.nan,
             去年同月=int(tot_all[yo]) if yo in tot_all else np.nan)
    rows.append(r)
mon = pd.DataFrame(rows); out['monthly']=mon

# ---------------- Overall: quarterly ----------------
qs = sorted({q_of(m) for m in allm})
qtot = {q: tot_all[[m for m in allm if q_of(m)==q]] for q in qs}
rows=[]
for q in sorted({q_of(m) for m in M}):
    s = qtot[q]; ms=[m for m in allm if q_of(m)==q]
    sub = X[ms].sum(axis=1); act=sub[sub>0]
    i = qs.index(q); pq = qs[i-1] if i>0 else None
    yq = f"{int(q[:3])-1}{q[3:]}"
    r = dict(季=q, 月數=len(s), 總計=int(s.sum()), 月平均=s.mean(), 月間SD=s.std(ddof=1) if len(s)>1 else np.nan,
             開立醫師數=len(act), 每位醫師平均=act.mean(), 醫師間SD=act.std(ddof=1),
             QoQ=(s.sum()/qtot[pq].sum()-1) if pq else np.nan, 前季=int(qtot[pq].sum()) if pq else np.nan,
             YoY=(s.sum()/qtot[yq].sum()-1) if yq in qtot else np.nan, 去年同季=int(qtot[yq].sum()) if yq in qtot else np.nan)
    if len(s)<3: r['備註']='僅115/10（當月未結束）'
    rows.append(r)
qtr = pd.DataFrame(rows); out['quarterly']=qtr

# ---------------- Overall: yearly ----------------
rows=[]
for y,ms,note in [(113,[m for m in M if y_of(m)==113],'全年'),(114,[m for m in M if y_of(m)==114],'全年'),(115,[m for m in M if y_of(m)==115],'1-10月（10月未結束）')]:
    s=tot_all[ms]; sub=X[ms].sum(axis=1); act=sub[sub>0]
    base=[m-100 for m in ms]; ok=all(b_ in tot_all.index for b_ in base); b=tot_all[base].sum() if ok else np.nan
    rows.append(dict(年度=y, 涵蓋=note, 月數=len(ms), 總計=int(s.sum()), 月平均=s.mean(), 月間SD=s.std(ddof=1),
                     開立醫師數=len(act), 每位醫師平均=act.mean(), 醫師間SD=act.std(ddof=1),
                     去年同期=b, YoY同期比較=(s.sum()/b-1) if ok else np.nan))
yr = pd.DataFrame(rows); out['yearly']=yr

# ---------------- Significance: overall ----------------
y = tot_all[M].values.astype(float)
# 1) change-point: optimal partition on log(y+1), Gaussian cost, BIC
z = np.log(y+1); n=len(z)
def sse(a,b): seg=z[a:b]; return ((seg-seg.mean())**2).sum()
best={}
for k in range(1,7):
    bestk=(np.inf,None)
    for cps in itertools.combinations(range(2,n-1),k-1):
        b=[0,*cps,n]
        if any(b[i+1]-b[i]<2 for i in range(len(b)-1)): continue
        c=sum(sse(b[i],b[i+1]) for i in range(len(b)-1))
        if c<bestk[0]: bestk=(c,b)
    rss,b=bestk; bic=n*np.log(rss/n)+ (2*k)*np.log(n)
    best[k]=(bic,b,rss)
kopt=min(best,key=lambda k:best[k][0]); bnds=best[kopt][1]
segs=[(M[bnds[i]],M[bnds[i+1]-1]) for i in range(len(bnds)-1)]
segrows=[]
for i in range(len(bnds)-1):
    v=y[bnds[i]:bnds[i+1]]
    segrows.append(dict(區段=f"{lab(segs[i][0])}–{lab(segs[i][1])}", 月數=len(v), 月平均=v.mean(), SD=v.std(ddof=1), 最小=v.min(), 最大=v.max()))
seg=pd.DataFrame(segrows)
# test adjacent segments (Welch t on log, + Mann-Whitney)
pv=[];pm=[]
for i in range(len(bnds)-2):
    a=z[bnds[i]:bnds[i+1]]; b=z[bnds[i+1]:bnds[i+2]]
    pv.append(stats.ttest_ind(a,b,equal_var=False).pvalue); pm.append(stats.mannwhitneyu(a,b).pvalue)
seg['與前段比較_Welch_p(log)']=[np.nan]+pv; seg['與前段比較_MannWhitney_p']=[np.nan]+pm
seg['BIC選擇區段數']=kopt
out['segments']=seg; out['bic']={k:best[k][0] for k in best}

# 2) quasi-Poisson GLM by quarter (complete quarters only), adjacent contrasts
qm=[m for m in M if m<=11509]
dq=pd.DataFrame({'y':tot_all[qm].values,'q':[q_of(m) for m in qm]})
Xd=pd.get_dummies(dq.q,drop_first=False).astype(float)
qorder=list(Xd.columns)
fit=sm.GLM(dq.y,Xd,family=sm.families.Poisson()).fit(scale='X2')
phi=fit.scale
cov=fit.cov_params(); bet=fit.params
rows=[];ps=[]
for i in range(1,len(qorder)):
    a,b=qorder[i-1],qorder[i]
    d=bet[b]-bet[a]; se=np.sqrt(cov.loc[a,a]+cov.loc[b,b]-2*cov.loc[a,b])
    p=2*stats.t.sf(abs(d/se),fit.df_resid)
    rows.append(dict(比較=f"{b} vs {a}", 率比RR=np.exp(d), RR_95CI下=np.exp(d-1.96*se), RR_95CI上=np.exp(d+1.96*se), p=p)); ps.append(p)
qc=pd.DataFrame(rows); qc['Holm校正p']=multipletests(ps,method='holm')[1]; qc['顯著(α=0.05)']=qc['Holm校正p']<0.05
# also YoY quarter contrasts using 113Q1-3 baselines? baseline quarters outside scope -> use counts directly with phi
yrows=[]
for q in ['114Q1','114Q2','114Q3','114Q4','115Q1','115Q2','115Q3']:
    yq=f"{int(q[:3])-1}{q[3:]}"; a=qtot[yq].sum(); b=qtot[q].sum()
    d=np.log(b/a); se=np.sqrt(phi*(1/a+1/b)); p=2*stats.norm.sf(abs(d/se))
    yrows.append(dict(比較=f"{q} vs {yq}", 本期=int(b), 去年同期=int(a), 率比RR=b/a, p=p))
yc=pd.DataFrame(yrows); yc['Holm校正p']=multipletests(yc.p,method='holm')[1]; yc['顯著(α=0.05)']=yc['Holm校正p']<0.05
out['qtest']=qc; out['ytest']=yc; out['phi']=phi
# overall Kruskal-Wallis across quarters
kw=stats.kruskal(*[dq.y[dq.q==q] for q in qorder]); out['kw']=kw

# 3) within-segment monthly outliers (quasi-Poisson Pearson residuals)
segid=np.zeros(n,int)
for i in range(len(bnds)-1): segid[bnds[i]:bnds[i+1]]=i
mu=np.array([y[segid==s].mean() for s in segid])
phis=[]
for s in range(len(bnds)-1):
    v=y[segid==s]; phis.append(max(1,((v-v.mean())**2/v.mean()).sum()/(len(v)-1)))
res=(y-mu)/np.sqrt(np.array([phis[s] for s in segid])*mu)
mon['所屬區段']=[seg.區段[s] for s in segid]; mon['區段平均']=mu; mon['區段內標準化殘差']=res
mon['區段內異常']=np.where(np.abs(res)>2,'是','')
# MoM significance with dispersion
mp=[]
for m in M:
    if allm.index(m)==0: mp.append(np.nan); continue
    prev=allm[allm.index(m)-1]; a=tot_all[prev]; b=tot_all[m]
    mp.append(2*stats.norm.sf(abs(np.log(b/a)/np.sqrt(phi*(1/a+1/b)))))
mp=np.array(mp); ok=~np.isnan(mp); h=np.full(len(mp),np.nan); h[ok]=multipletests(mp[ok],method='holm')[1]
mon['MoM_p(過度離散校正)']=mp; mon['MoM_Holm_p']=h
yp=[]
for m in M:
    if m-100 not in tot_all.index: yp.append(np.nan); continue
    a=tot_all[m-100]; b=tot_all[m]
    yp.append(2*stats.norm.sf(abs(np.log(b/a)/np.sqrt(phi*(1/a+1/b)))))
yp=np.array(yp); ok=~np.isnan(yp); h=np.full(len(yp),np.nan); h[ok]=multipletests(yp[ok],method='holm')[1]
mon['YoY_p(過度離散校正)']=yp; mon['YoY_Holm_p']=h

# ---------------- Per doctor ----------------
D=XS.copy()
info=pd.DataFrame(index=D.index)
info['總計']=D.sum(axis=1); info['開立月數']=(D>0).sum(1)
info['月平均(34個月)']=D.mean(1); info['月SD(34個月)']=D.std(1,ddof=1)
info['有開立月平均']=D.where(D>0).mean(1); info['有開立月SD']=D.where(D>0).std(1,ddof=1)
info['最高月']=D.idxmax(1).map(lab); info['最高月次數']=D.max(1)
info['首次出現']=D.apply(lambda r: lab(r[r>0].index[0]) if r.sum() else '',axis=1)
# yearly
Y113=X[[m for m in allm if 11301<=m<=11312]].sum(1); Y114=X[[m for m in allm if 11401<=m<=11412]].sum(1); Y115=X[[m for m in allm if 11501<=m<=11510]].sum(1)
S114=X[[m for m in allm if 11401<=m<=11410]].sum(1)
info['113全年']=Y113; info['114全年']=Y114; info['115(1-10月)']=Y115; info['114(1-10月)同期']=S114
info['YoY 115 vs 114同期']=np.where(S114>0,Y115/S114.replace(0,np.nan)-1,np.nan)
info['YoY 114 vs 113']=np.where(Y113>0, Y114/Y113.replace(0,np.nan)-1, np.nan)
# exact Poisson rate test 115(1-10) vs 114(1-10)
pp=[]
for a,b in zip(S114,Y115):
    pp.append(stats.binomtest(int(b),int(a+b),0.5).pvalue if a+b>0 else np.nan)
info['同期比較p(精確檢定)']=pp
msk=info['同期比較p(精確檢定)'].notna()
info.loc[msk,'同期比較FDR q']=multipletests(info.loc[msk,'同期比較p(精確檢定)'],method='fdr_bh')[1]
# heterogeneity across 25 months (Poisson dispersion test) for doctors with total>=10
het=[]
for idx,r in D.iterrows():
    v=r.values.astype(float)
    if v.sum()<10: het.append(np.nan); continue
    chi=((v-v.mean())**2/v.mean()).sum(); het.append(stats.chi2.sf(chi,len(v)-1))
info['月間異質性p']=het
m2=info['月間異質性p'].notna()
info.loc[m2,'月間異質性FDR q']=multipletests(info.loc[m2,'月間異質性p'],method='fdr_bh')[1]
info=info.sort_values('總計',ascending=False)
out['doc_info']=info

# quarterly per doctor + QoQ
QL=sorted({q_of(m) for m in M})
DQ=pd.DataFrame({q: X[[m for m in allm if q_of(m)==q]].sum(1) for q in QL})
DQq=DQ[QL].copy()
qoq=pd.DataFrame({q:((DQ[q]/DQ[QL[QL.index(q)-1]].replace(0,np.nan)-1) if QL.index(q)>0 else np.nan) for q in QL})
out['doc_q']=DQq.loc[info.index]; out['doc_qoq']=qoq.loc[info.index]
out['doc_m']=D.loc[info.index]

# per doctor-month anomalies: Poisson upper tail vs doctor's own 25-month mean, BH-FDR across all doctor-months (doctors total>=10)
an=[]
for idx,r in D.iterrows():
    if r.sum()<10: continue
    lam=r.mean()
    for m,v in r.items():
        if v>0:
            an.append(dict(no=idx[0],name=idx[1],月份=lab(m),次數=int(v),該醫師月平均=lam,倍數=v/lam,p=stats.poisson.sf(v-1,lam)))
an=pd.DataFrame(an); an['FDR q']=multipletests(an.p,method='fdr_bh')[1]
an=an[an['FDR q']<0.01].sort_values(['FDR q','次數'],ascending=[True,False])
out['doc_anom']=an

# contribution to surge: 115/07-09 vs 114/07-09 ; and to drop 114/03-115/05 vs 113/10-114/02
def contrib(after,before,label):
    a=X[after].sum(1); b=X[before].sum(1)
    c=pd.DataFrame({'前期':b,'後期':a}); c['變化']=c.後期-c.前期
    tot=c.變化.sum(); c['佔總變化%']=c.變化/tot
    c=c.reindex(c.變化.abs().sort_values(ascending=False).index)
    return c,label
out['contrib_surge']=contrib([11507,11508,11509],[11407,11408,11409],'115Q3 vs 114Q3')
out['contrib_drop']=contrib([11407,11408,11409],[11307,11308,11309],'114Q3 vs 113Q3')
# new doctors in 115/06+
newdoc=info[info['首次出現'].isin(['115/06','115/07','115/08','115/09','115/10'])]
out['newdoc']=newdoc
pickle.dump(out,open(BUILD/'out.pkl','wb'))

pd.set_option('display.width',250); pd.set_option('display.max_columns',30); pd.set_option('display.float_format',lambda x:f'{x:.3f}')
print(mon.to_string()); print(qtr.to_string()); print(yr.to_string())
print('BIC',out['bic']); print(seg.to_string()); print('phi',phi, 'KW',kw)
print(qc.to_string()); print(yc.to_string())
print(info.head(25).to_string())
print(an.head(40).to_string()); print(len(an))
print(out['contrib_surge'][0].head(15).to_string()); print(out['contrib_drop'][0].head(15).to_string())
print(newdoc[['總計','首次出現']].to_string())
