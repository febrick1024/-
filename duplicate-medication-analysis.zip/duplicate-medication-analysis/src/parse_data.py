"""讀取原始 .xls（工作表1 樞紐表），轉成「醫師 × 月份」寬表，並與 SQL Results 交叉驗證。"""
import sys, pandas as pd
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'data' / 'duplicate_meds_11301-11510.xls'
BUILD = ROOT / 'build'; BUILD.mkdir(exist_ok=True)

raw = pd.read_excel(SRC, sheet_name='工作表1', header=None)
hdr = raw.iloc[3].tolist()
rows = []
for i in range(4, len(raw) - 1):                 # 最後一列為「總計」
    r = raw.iloc[i]
    if isinstance(r[0], str) and '合計' in r[0]:  # 跳過每位醫師的「合計」小計列
        continue
    rows.append([str(r[0]).strip(), str(r[1]).strip()] + r[2:36].tolist())
df = pd.DataFrame(rows, columns=['no', 'name'] + [int(h) for h in hdr[2:36]]).fillna(0)

# 交叉驗證：與 SQL Results 每月加總需一致
sql = pd.read_excel(SRC, sheet_name='SQL Results')
monthly = df.iloc[:, 2:].sum().astype(int)
assert sql.groupby('YYY_MM')['COUNT(*)'].sum().astype(int).equals(monthly), '工作表1 與 SQL Results 不一致'
print(f'醫師數 {len(df)}，總次數 {monthly.sum()}，驗證通過')
df.to_pickle(BUILD / 'wide.pkl')
